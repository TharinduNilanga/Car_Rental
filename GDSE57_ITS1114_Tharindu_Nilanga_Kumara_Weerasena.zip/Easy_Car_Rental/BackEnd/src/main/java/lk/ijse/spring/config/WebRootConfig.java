package lk.ijse.spring.config;

/**
 * @author Tharindu Nilanga
 * @created 7/10/2022
 */
public class WebRootConfig {
}
