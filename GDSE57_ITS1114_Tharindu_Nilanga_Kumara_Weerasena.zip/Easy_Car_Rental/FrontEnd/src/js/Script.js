
var customerNavBar=document.getElementById("navbarheader");
var adminNavBar=document.getElementById("navbarheader1");
var driverNavBar=document.getElementById("navbarheader2");




var dashBoardSection=document.getElementById("DashBoard");
var btnMoreGeneralCars=$('#btnDashBoardCarGeneral');
var btnMorePremiumCars=$('#btnDashBoardCarPremium');
var btnMoreLuxuryCars=$('#btnDashBoardCarLuxury');
var btnLogin=$("#btnLogIn")
var btnCustomerSignUp=$("#btnSignUp");

var loginSection=document.getElementById("login");
var signUpContainer=document.getElementById("SignUp");
var btnCustomerLogin=$('#btnSignUpLogin');

var customerAddRentRequestSection=document.getElementById("CustomerRent");
var customerCarListSection=document.getElementById("CarList");
var customerDetailsSection=document.getElementById("CustomerDetails");

var adminAddRentSection=document.getElementById("adminAddRent");
var adminAddReturnSection=document.getElementById("adminAddReturn");
var adminAddDetailsSection=document.getElementById("adminDetails");
var adminAddCarSection=document.getElementById("adminCar");
var adminAddMaintenanceSection=document.getElementById("adminMaintenance");
var adminCustomerDetailsSection=document.getElementById("adminCustomerDetails");
var adminIncomeSection=document.getElementById("adminIncome");

var driverSection=document.getElementById("Driver")

btnLogin.click(function () {
    alert("success")

    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="block";
    signUpContainer.style.display="none";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})
btnCustomerSignUp.click(function () {
    alert("success")
    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="none";
    signUpContainer.style.display="block";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})
btnMoreGeneralCars.click(function () {
    alert("success")

    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="block";
    signUpContainer.style.display="none";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})
btnMorePremiumCars.click(function () {
    alert("success")

    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="block";
    signUpContainer.style.display="none";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})
btnMoreLuxuryCars.click(function () {
    alert("success")

    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="block";
    signUpContainer.style.display="none";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})
btnCustomerLogin.click(function () {
    alert("success")

    dashBoardSection.style.opacity='50%'
    customerNavBar.style.display="none";
    adminNavBar.style.display="none";
    driverNavBar.style.display="none";
    loginSection.style.display="block";
    signUpContainer.style.display="none";
    customerAddRentRequestSection.style.display="none";
    customerCarListSection.style.display="none";
    customerDetailsSection.style.display="none";
    adminAddRentSection.style.display="none";
    adminAddReturnSection.style.display="none";
    adminAddDetailsSection.style.display="none";
    adminAddCarSection.style.display="none";
    adminAddMaintenanceSection.style.display="none";
    adminCustomerDetailsSection.style.display="none";
    adminIncomeSection.style.display="none";
    driverSection.style.display="none";
})

